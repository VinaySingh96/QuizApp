export const APP_INFO = {
  appName: 'MyApp',
  companyName: 'MyCompany Inc.',
  version: '1.0.0',
  copyright: '© 2024 MyCompany Inc. All rights reserved.',
};
