export const EXAMS = [
  { label: 'SSC CGL', value: 'ssc_cgl' },
  { label: 'REACT UI', value: 'react_ui' },
  { label: 'SSC CHSL', value: 'ssc_chsl' },
  { label: 'UPSC', value: 'upsc' },
  { label: 'Railway', value: 'railway' },
  { label: 'Banking Exams', value: 'banking' },
  { label: 'State PCS', value: 'state_pcs' },
  { label: 'Teaching Exams', value: 'teaching' },
]